package interface_calculator;

/**
 *
 * @author Shady Emad
 */
public class Interface_calculator {

    public static void main(String[] args) {
        new calc1().setVisible(true);
    }
    
}
