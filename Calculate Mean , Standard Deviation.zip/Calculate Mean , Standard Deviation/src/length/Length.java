/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package length;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.lang.*;
/**
 *
 * @author Shady Emad
 */
public class Length {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    double a = Double.parseDouble(JOptionPane.showInputDialog("write the value of a"));
    double b = Double.parseDouble(JOptionPane.showInputDialog("write the value of b"));
    double c = Double.parseDouble(JOptionPane.showInputDialog("write the value of cc"));
    double d = Double.parseDouble(JOptionPane.showInputDialog("write the value of d"));
    double mean = (a+b+c+d)/4;
    
    double squ_distance_a = (mean - a)*(mean - a) ;
    double squ_distance_b = (mean - b)*(mean - b) ;
    double squ_distance_c = (mean - c)*(mean - c) ;
    double squ_distance_d = (mean - d)*(mean - d) ;
    double aver_distance = (squ_distance_a + squ_distance_b + squ_distance_c + squ_distance_d)/4;
    double std = Math.sqrt(aver_distance);
    
    JOptionPane.showMessageDialog(null, "MEAN is "+ mean);
    JOptionPane.showMessageDialog(null, "Standard Deviation is "+ std);
    

  
          
    }
    
}
