package Project;

/**
 *
 * @author Shady Emad
 */
public class Project_GUI {

    public static void main(String[] args) {
        new Login().setVisible(true);
    }
    
}
